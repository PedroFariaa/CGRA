#ifndef MYCHAIR_H
#define MYCHAIR_H

#include "CGFobject.h"

class myChair: public CGFobject {
	public:
		void draw();
};

#endif