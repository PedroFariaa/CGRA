#ifndef MYFLOOR_H
#define MYFLOOR_H


#include "CGFobject.h"

class myFloor: public CGFobject {
	public:
		void draw();
};

#endif