#ifndef TPSCENE_H
#define TPSCENE_H

#include "ExampleObject.h"
#include "CGFscene.h"

class TPscene : public CGFscene
{
public:
	void init();
	void display();
};

#endif