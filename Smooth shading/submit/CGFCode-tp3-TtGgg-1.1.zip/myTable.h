#ifndef MYTABLE_H
#define MYTABLE_H

#include "CGFobject.h"

class myTable: public CGFobject {
	public:
		void draw();
};

#endif